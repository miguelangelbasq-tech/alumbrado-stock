package ar.com.emaservicios.alumbrado;

import android.os.Bundle;
import android.webkit.WebView;
import androidx.activity.OnBackPressedCallback;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // «Atrás»: si la app tiene adónde volver (otra hoja), vuelve; si ya está en la primera, la manda al fondo
        // en vez de cerrarla, así al volver a abrirla aparece al instante (como WhatsApp).
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                WebView w = (bridge != null) ? bridge.getWebView() : null;
                if (w != null && w.canGoBack()) {
                    w.goBack();
                } else {
                    moveTaskToBack(true);
                }
            }
        });
    }
}
