# APK 1.4 — notas para programar el index

Para quien programe el `index.html` (ORIGINAL) después de la APK 1.4.
APK 1.4 = versionCode 5 / versionName «1.4». Capacitor 8.6.0, `useLegacyBridge: true`, el cargador local (`www/index.html`) **no cambió**.

## 0. Cómo llegar a cada plugin (y detectar si está)

El index no tiene bundler: los plugins se usan por el puente nativo, igual que hoy `Capacitor.Plugins.CapacitorHttp` / `BackgroundGeolocation`. Cada plugin nativo queda registrado con su nombre en `Capacitor.Plugins`.

```js
// Devuelve el plugin si está en ESTA app; null en la web, en la APK 1.3 o si falta.
function plug(nombre) {
  var C = window.Capacitor;
  if (!C || !C.isNativePlatform || !C.isNativePlatform()) return null;          // web / PWA
  if (C.isPluginAvailable && !C.isPluginAvailable(nombre)) return null;        // APK 1.3 o anterior
  return (C.Plugins && C.Plugins[nombre]) || (C.registerPlugin ? C.registerPlugin(nombre) : null);
}
```

- Usar siempre `isPluginAvailable(nombre)` antes: en la APK 1.3 el objeto puede existir como proxy pero el método falla con «not implemented».
- **Nunca** usar el global `window.SpeechRecognition` creyendo que es el plugin: ese es el de la web. El nativo es `Capacitor.Plugins.SpeechRecognition`.
- Versión del APK (ya estaba): `Capacitor.Plugins.App.getInfo()` → `{name, id, build: "5", version: "1.4"}`. Para saber si hay 1.4: `+build >= 5`.
- Todas las llamadas devuelven promesas; los eventos se escuchan con `await P.addListener(evento, fn)` → `{remove()}`.
- Escribir todo compatible con Chrome 80 si va en código `text/plain` (asistente dormido): sin `?.`, sin `??`.

| Nombre en `Capacitor.Plugins` | Paquete npm | Versión |
|---|---|---|
| `SpeechRecognition` | `@capgo/capacitor-speech-recognition` | 8.4.6 |
| `TextToSpeech` | `@capacitor-community/text-to-speech` | 8.0.2 |
| `Device` | `@capacitor/device` | 8.0.3 |
| `Network` | `@capacitor/network` | 8.0.1 |
| `LocalNotifications` | `@capacitor/local-notifications` | 8.3.1 |
| `Badge` | `@capawesome/capacitor-badge` | 8.0.4 |
| `NativeBiometric` | `@capgo/capacitor-native-biometric` | 8.9.1 |

Los de la 1.3 siguen igual (`App`, `Camera`, `Filesystem`, `Share`, `FileOpener`, `Printer`, `PushNotifications`, `BarcodeScanner`, `BackgroundGeolocation`, `KeepAwake`).

---

## 1. Micrófono — `SpeechRecognition`

Dictado con el reconocedor de Google del celular (el WebView no tiene `webkitSpeechRecognition`).

**Permiso:** `RECORD_AUDIO`. `start()` **no** lo pide solo: si no está, rechaza con `"Missing permission"`. Pedirlo antes, la primera vez que se toca el 🎤:

```js
var SR = plug('SpeechRecognition');
if (SR) {
  var disp = await SR.available();                       // {available:true/false} (false si no hay servicio de Google)
  var p = await SR.checkPermissions();                   // {speechRecognition:'granted'|'denied'|'prompt'}
  if (p.speechRecognition !== 'granted') p = await SR.requestPermissions();   // Android muestra «Permitir que grabe audio»
  if (p.speechRecognition !== 'granted') { /* avisar: «Activá el micrófono en Ajustes › Apps › EMA Alumbrado › Permisos» */ }
}
```

Si la persona negó dos veces, Android ya no vuelve a preguntar (`denied`): solo desde Ajustes.

**Forma simple (un dictado, sin texto en vivo):**
```js
var r = await SR.start({ language: 'es-AR', maxResults: 1, partialResults: false, popup: false });
var texto = (r.matches && r.matches[0]) || '';
```
Termina solo cuando la persona deja de hablar (~1–2 s de silencio). Si no dijo nada, rechaza (código `NO_MATCH` / `SPEECH_TIMEOUT`).

**Forma con texto en vivo (para el «modo charla»):**
```js
await SR.addListener('partialResults', function (e) { ultimo = (e.matches && e.matches[0]) || ultimo; /* mostrar en #iaTxt */ });
await SR.addListener('listeningState', function (e) {
  // e.state: 'startingListening' | 'started' | 'stoppingListening' | 'stopped'
  // e.reason: 'userStart' | 'userStop' | 'forceStop' | 'results' | 'silence' | 'error' | 'unknown'
});
await SR.addListener('error', function (e) { /* e.code: NO_MATCH, SPEECH_TIMEOUT, NETWORK, AUDIO, RECOGNIZER_BUSY, INSUFFICIENT_PERMISSIONS… */ });
await SR.addListener('readyForNextSession', function () { /* ya se puede llamar start() de nuevo */ });
await SR.start({ language: 'es-AR', maxResults: 1, partialResults: true, popup: false });
// Con partialResults:true, start() se resuelve apenas arranca. El resultado final llega como un último
// 'partialResults' y enseguida 'listeningState' {state:'stopped', reason:'results'}.
```
- Cortar a mano: `SR.stop()` (entrega lo que haya) o `SR.forceStop()` (corta ya). `SR.isListening()` → `{listening}`.
- No llamar `start()` otra vez hasta `readyForNextSession` (si no: `RECOGNIZER_BUSY`).
- `muteRecognizerBeep: true` saca el «bip» de Android al empezar (en algunos celus no hace caso). Para la cuadrilla conviene **dejar el bip** como aviso de «ya podés hablar».
- `popup: true` muestra el cartel de Google de Android en vez de escuchar «adentro» (no sirve para el modo charla).
- **Idioma:** `es-AR` lo tiene el reconocedor de Google. Si `SR.getSupportedLanguages()` no lo trae (o da error de idioma), usar `es-ES` o `es-US`.
- Funciona sin señal solo si el celu tiene bajado el paquete de español sin conexión (Ajustes de Google › Voz). Con `useOnDeviceRecognition:true` se fuerza eso (Android 13+); no recomendado de entrada.

**Web y APK 1.3:** si `plug('SpeechRecognition')` es null, seguir con `webkitSpeechRecognition` como hoy (en la PC anda; en la 1.3 no, ocultar el 🎤 o decir «Hace falta la app 1.4»).

---

## 2. Que el Asistente hable — `TextToSpeech`

Sin permisos.

```js
var TTS = plug('TextToSpeech');
var lang = 'es-AR';
try { if (!(await TTS.isLanguageSupported({ lang: 'es-AR' })).supported) lang = 'es-US'; } catch (e) { lang = 'es-ES'; }
await TTS.speak({ text: 'Listo, armé la orden.', lang: lang, rate: 1.0, pitch: 1.0, volume: 1.0, queueStrategy: 0 });
// ← la promesa se resuelve CUANDO TERMINA DE HABLAR (onDone de Android). Rechaza si el motor falla.
```
- `queueStrategy: 0` = corta lo anterior y habla esto; `1` = lo pone en cola.
- `TTS.stop()` corta. **Ojo:** al cortar con `stop()` la promesa de `speak()` que estaba hablando **no se resuelve nunca** (el plugin no avisa el «stop»). No esperar esa promesa: usar una bandera propia (ver §6).
- `TTS.addListener('onRangeStart', e => …)` da `{start, end, spokenWord}` mientras habla (sirve para resaltar la palabra; no hace falta).
- `TTS.getSupportedVoices()` → `{voices:[{voiceURI, name, lang, …}]}`; se elige una con `voice: <índice>`.
- Si el celular no tiene voz en español: `TTS.openInstall()` abre la instalación de datos de voz de Google.
- Textos largos: Android acepta hasta ~4000 caracteres por `speak`. Partir por oraciones (≤ 3000) y llamar `speak` una tras otra (con `await`).
- Antes de hablar, sacar del texto lo que no se lee bien: emojis, `**`, `#`, tablas, URLs; «m²» → «metros cuadrados», «OT-2026-014» → «orden 14».
- En la web: `speechSynthesis` (sí existe en Chrome); en la 1.3: también `speechSynthesis` del WebView (suele andar, sin voz elegible).

---

## 3. Datos del celular — `Device` y `Network`

Sin permisos.

```js
var D = plug('Device'), N = plug('Network'), A = plug('App');
var info = await D.getInfo();          // {model:'moto g24 power', manufacturer:'motorola', platform:'android', operatingSystem:'android',
                                       //  osVersion:'14', androidSDKVersion:34, name:'Moto de Juan' (puede faltar), webViewVersion:'…', memUsed, isVirtual}
var bat  = await D.getBatteryInfo();   // {batteryLevel: 0.43, isCharging:false}   (0 a 1)
var id   = await D.getId();            // {identifier:'…'}  (ANDROID_ID: cambia si se resetea el celu)
var red  = await N.getStatus();        // {connected:true, connectionType:'wifi'|'cellular'|'none'|'unknown'}
await N.addListener('networkStatusChange', function (s) { /* mismo formato */ });
var app  = await A.getInfo();          // {version:'1.4', build:'5', …}
```
Para `diagnostico_equipo` / `pushSubs` / `ubicacionVivo`: guardar `{modelo, android: osVersion, sdk, bateria: Math.round(batteryLevel*100), cargando, red: connectionType, apk: version}`. En la web: `navigator.userAgent`, `navigator.getBattery?.()`, `navigator.onLine`.

---

## 4. Recordatorios en el celular — `LocalNotifications` (+ `Badge`)

**Permiso:** `POST_NOTIFICATIONS` (Android 13+; es el mismo que ya pedían los avisos FCM de la 1.3: si ya lo dieron, no vuelve a preguntar).

```js
var LN = plug('LocalNotifications');
var p = await LN.checkPermissions();                         // {display:'granted'|'denied'|'prompt'}
if (p.display !== 'granted') p = await LN.requestPermissions();
// Canal propio (una vez; si ya existe no pasa nada). importance 4 = suena y aparece arriba.
await LN.createChannel({ id: 'recordatorios', name: 'Recordatorios', description: 'Recordatorios de la app EMA',
                          importance: 4, visibility: 1, vibration: true });
await LN.schedule({ notifications: [{
  id: 1001,                                  // entero de 32 bits, único: con el mismo id se reemplaza
  title: 'Mañana: plaza ALBERDI',
  body: 'Llevar 3 jabalinas y el telurímetro',
  channelId: 'recordatorios',
  schedule: { at: new Date(Date.now() + 60 * 60 * 1000), allowWhileIdle: true },
  extra: { ir: 'mistareas', otId: 'OT-2026-014' }
}]});
await LN.addListener('localNotificationActionPerformed', function (a) { var x = a.notification.extra; /* abrir la hoja */ });
await LN.cancel({ notifications: [{ id: 1001 }] });
var pend = await LN.getPending();            // {notifications:[…]}
```
- Ícono y color ya vienen configurados (`capacitor.config.json` → `smallIcon: ic_stat_ema`, `iconColor: #28285E`).
- El evento del toque queda guardado hasta que el index se suscribe (llega aunque la app estuviera cerrada y la abra el cargador): suscribirse apenas arranca.
- Repetir: `schedule: { on: { hour: 7, minute: 30 }, allowWhileIdle: true }` (todos los días) o `every: 'day'`.
- Android 14 trae apagadas las «alarmas exactas»: puede llegar unos minutos tarde. `LN.checkExactNotificationSetting()` → `{exact_alarm:'granted'|'denied'}`; `LN.changeExactNotificationSetting()` abre Ajustes. Para recordatorios de obra no hace falta.
- Se reprograman solos si se reinicia el celu.

**Número sobre el ícono — `Badge`:**
```js
var B = plug('Badge');
var ok = (await B.isSupported()).isSupported;    // depende del lanzador del celular
await B.set({ count: 5 });  await B.clear();  (await B.get()).count;
```
- Funciona con lanzadores que muestran números (Samsung, Xiaomi, Huawei, Sony, algunos más). **En Motorola, Pixel y el Android «puro» no hay número**: Android muestra solo un puntito cuando hay una notificación sin leer. No prometer el número.
- Sin permiso propio (en Android `checkPermissions` da `granted`).

---

## 5. Bloqueo con huella o cara — `NativeBiometric`

Es un **bloqueo de la app**, no un login: Firebase ya deja la sesión abierta. **No usar** `setCredentials`/`getCredentials` (guardan usuario y contraseña): no se guardan contraseñas.
Permiso `USE_BIOMETRIC`: se concede al instalar, no aparece cartel.

```js
var BIO = plug('NativeBiometric');
var d = await BIO.isAvailable({ useFallback: true });
// {isAvailable, biometryType (0 nada, 3 huella, 4 cara, 5 iris, 6 varias, 7 solo PIN/patrón), deviceIsSecure, strongBiometryIsAvailable, errorCode?}
// Ofrecer «Pedir huella al abrir» solo si d.isAvailable || d.deviceIsSecure.

try {
  await BIO.verifyIdentity({
    title: 'EMA Alumbrado',
    subtitle: 'Tocá el sensor o mirá a la cámara',
    allowedBiometryTypes: [6, 7]     // huella/cara + PIN o patrón del celular como plan B
    // con 7 incluido Android NO deja poner negativeButtonText (lo reemplaza «Usar PIN»)
  });
  // ok → sacar el velo
} catch (e) {
  // e.code (texto): '10' falló, '16' canceló la persona, '15' lo cortó el sistema (p. ej. se apagó la pantalla), '2'/'4' bloqueado por intentos, '3' no tiene huella cargada, '14' no tiene PIN, '1' no hay sensor
  // Mostrar velo con «Probar de nuevo» y «Salir y entrar con usuario y contraseña» (firebase.auth().signOut()).
}
```
Diseño sugerido:
- Preferencia por aparato: `localStorage ema.bloqueo` = `{activo:true, minutos:5}` (se activa desde el menú; antes de activar, pedir una verificación para probar).
- **Al abrir** (después de que Firebase confirma el usuario) y **al volver** con `App.addListener('appStateChange', s => …)`: guardar la hora al pasar a `isActive:false`; al volver con `isActive:true`, pedir huella solo si pasaron ≥ N minutos.
- **Trampa:** `verifyIdentity` abre una pantalla de Android encima → la app pasa a `isActive:false` y vuelve. Lo mismo la cámara (`Camera.takePhoto`), compartir, el selector de archivos y el lector QR. Ignorar el regreso mientras haya una de esas en curso (bandera propia), si no, pide huella en bucle.
- Nunca dejar a la persona trabada: siempre el botón de «Salir y entrar con contraseña».
- En la web y en la 1.3: no ofrecer la opción.
- Con `allowedBiometryTypes:[6,7]` en Android 9/10 (API 28–29) puede ir directo al PIN: probar en un celu viejo.

---

## 6. «Modo charla» del Asistente (escuchar → mandar → hablar → escuchar)

Todo con los plugins de arriba + `KeepAwake` (ya estaba en la 1.3). No hace falta otro plugin ni otro permiso: `RECORD_AUDIO` (ya pedido para el 🎤). El motor de voz de Android pide el foco de audio solo (baja la música mientras habla) y el reconocedor de Google también: no hay que tocar nada.

```js
var SR = plug('SpeechRecognition'), TTS = plug('TextToSpeech'), KA = plug('KeepAwake'), APP = plug('App');
var charla = { on: false, hablando: false, cortar: null, silencios: 0, texto: '' };

async function entrar() {
  // permisos (§1) → si no hay, salir
  charla.on = true; charla.silencios = 0;
  try { await KA.keepAwake(); } catch (e) {}            // pantalla prendida mientras dura la charla
  await SR.removeAllListeners();
  await SR.addListener('partialResults', function (e) { charla.texto = (e.matches && e.matches[0]) || charla.texto; pintarEnVivo(charla.texto); });
  await SR.addListener('listeningState', function (e) { if (e.state === 'stopped') terminoDeHablar(e.reason); });
  await SR.addListener('error', function (e) { charla.ultErr = e.code; });
  APP.addListener('appStateChange', function (s) { if (!s.isActive) salir(); });   // si se va de la app, se corta todo
  escuchar();
}

async function escuchar() {
  if (!charla.on) return;
  charla.texto = ''; charla.ultErr = '';
  estado('🎤 Te escucho…');
  try { await SR.start({ language: 'es-AR', maxResults: 1, partialResults: true, popup: false }); }
  catch (e) { estado('No pude usar el micrófono'); salir(); }
}

async function terminoDeHablar(motivo) {                // lo llama 'listeningState' stopped
  if (!charla.on || charla.hablando) return;
  var t = charla.texto.trim();
  if (!t) {                                             // NO_MATCH / SPEECH_TIMEOUT: no dijo nada
    if (++charla.silencios >= 3) { estado('Pausado. Tocá 🎤 para seguir.'); return salir(true); }
    return setTimeout(escuchar, 400);                   // esperar 'readyForNextSession' o ~400 ms
  }
  charla.silencios = 0;
  if (/^(listo|chau|terminamos|cortá|salir)\b/i.test(t)) return salir();
  estado('Pensando…');
  var resp = await asistenteEnviar(t);                  // el mismo bucle de hoy; pedirle respuestas cortas («respondé para voz, 2-3 oraciones»)
  await hablar(paraVoz(resp));                          // limpiar emojis/markdown (§2)
  if (charla.on) setTimeout(escuchar, 300);             // recién cuando terminó de hablar: no se escucha a sí misma
}

function hablar(texto) {
  charla.hablando = true; estado('🔊 Hablando… (tocá para cortar)');
  return new Promise(function (listo) {
    charla.cortar = function () { try { TTS.stop(); } catch (e) {} fin(); };   // stop() no resuelve speak(): por eso la bandera
    function fin() { if (!charla.hablando) return; charla.hablando = false; charla.cortar = null; listo(); }
    var partes = partirOraciones(texto, 3000), i = 0;
    (function sig() { if (!charla.hablando) return; if (i >= partes.length) return fin();
      TTS.speak({ text: partes[i++], lang: 'es-AR', rate: 1.0, queueStrategy: 0 }).then(sig, fin); })();
  });
}

// Botón grande mientras habla: «✋ Cortar y hablar» → if (charla.cortar) charla.cortar();  (al terminar sigue solo escuchando)
async function salir() {
  charla.on = false;
  if (charla.cortar) charla.cortar();
  try { await SR.forceStop(); } catch (e) {}
  try { await SR.removeAllListeners(); } catch (e) {}
  try { await KA.allowSleep(); } catch (e) {}
}
```

Notas del ciclo:
- **Fin de la frase:** lo detecta Android solo (silencio de ~1–2 s) → `listeningState` `stopped` con `reason: 'results'`; si no dijo nada, `reason: 'error'` con `NO_MATCH`/`SPEECH_TIMEOUT`.
- **No escucharse:** el micrófono se abre recién después de que `speak()` se resuelve (fin real del audio) + 300 ms.
- **Cortarla hablando («barge-in») con la voz: no es confiable** con estos plugins: el reconocedor de Android no tiene cancelación de eco, así que si se abre el micrófono mientras habla el parlante, se escucha a sí mismo (y en varios celus el reconocedor ni arranca mientras suena el motor de voz). Lo seguro: **un toque en cualquier parte del panel** corta la voz y vuelve a escuchar. Con auriculares con cable se podría probar a escuchar mientras habla, pero queda **a probar**.
- **Auriculares Bluetooth:** la voz sale por el auricular, pero el reconocedor usa el micrófono del celular (Android no pasa el micrófono BT al dictado sin código nativo). A probar.
- **Bip:** Android hace un «bip» cada vez que abre el micrófono; en modo charla sirve como «tu turno». Si molesta: `muteRecognizerBeep: true` en `start`.
- **Costo:** cada vuelta es un pedido al Worker `ema-ia`; con 3 silencios seguidos se pausa solo para no gastar.
- Sin señal: el reconocedor de Google necesita internet (salvo paquete sin conexión) y el Asistente también: mostrar «Sin señal» con `Network.getStatus()`.

---

## 7. Chequeo rápido para el index

```js
window.__apk14 = !!(plug('SpeechRecognition') && plug('NativeBiometric'));   // true solo con la 1.4
```
En la 1.3: el 🎤 cae al `webkitSpeechRecognition` (que no anda en el WebView: mejor ocultarlo y mostrar «Actualizá la app a la 1.4»), sin bloqueo con huella, sin recordatorios locales.
