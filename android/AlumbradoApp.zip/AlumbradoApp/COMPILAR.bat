@echo off
chcp 65001 >nul
title Armando la app EMA Alumbrado (APK)
cd /d "%~dp0"
echo.
echo  ==== Armando la app de Android (EMA Alumbrado) ====
echo.
set "SDK=%LOCALAPPDATA%\Android\Sdk"
if not exist "%SDK%\platforms" (
  echo  Falta el SDK de Android. Abri Android Studio una vez, elegi "Standard" y termina el asistente.
  echo  Despues volve a abrir este archivo.
  echo.
  pause
  exit /b 1
)
rem --- Java 21 propio (el de Android Studio nuevo es Java 25 y Gradle 8.14 no lo acepta) ---
set "JDK="
for /d %%D in ("%~dp0jdk21\jdk-21*") do set "JDK=%%~fD"
if not defined JDK (
  echo  Bajando Java 21 (una sola vez, unos 200 MB^)...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://api.adoptium.net/v3/binary/latest/21/ga/windows/x64/jdk/hotspot/normal/eclipse' -OutFile '%~dp0jdk21.zip'; Expand-Archive -Path '%~dp0jdk21.zip' -DestinationPath '%~dp0jdk21' -Force; Remove-Item '%~dp0jdk21.zip'"
  for /d %%D in ("%~dp0jdk21\jdk-21*") do set "JDK=%%~fD"
)
if not defined JDK (
  echo  No se pudo bajar Java 21. Revisa internet y volve a abrir este archivo.
  echo.
  pause
  exit /b 1
)
set "JAVA_HOME=%JDK%"
set "PATH=%JDK%\bin;%PATH%"
echo  Java: %JDK%
cd /d "%~dp0android"
rem --- v1.3: avisos con la app cerrada: hace falta el archivo de Firebase (google-services.json) ---
if exist "app\google-services.json" goto :conAvisos
  echo.
  echo  ATENCION: falta el archivo google-services.json en la carpeta android\app
  echo  Sin ese archivo la app anda igual, pero NO le van a llegar los avisos con la app cerrada.
  echo  Como bajarlo: mira el LEEME.txt, parte "AVISOS CON LA APP CERRADA".
  echo.
  set "SEGUIR="
  set /p SEGUIR= Escribi S y Enter para seguir sin avisos, o cerra esta ventana para ponerlo primero: 
  if /I not "%SEGUIR%"=="S" exit /b 1
:conAvisos
set "SDKF=%SDK:\=/%"
> local.properties echo sdk.dir=%SDKF%
call gradlew.bat --stop >nul 2>&1
echo  La primera vez baja cosas de internet y tarda varios minutos (5 a 15). No cierres esta ventana.
echo.
call gradlew.bat assembleDebug
if errorlevel 1 (
  echo.
  echo  ***** Hubo un error. Sacale una foto a esta ventana y mandasela a Claude. *****
  echo.
  pause
  exit /b 1
)
copy /Y "app\build\outputs\apk\debug\app-debug.apk" "%~dp0EMA-Alumbrado.apk" >nul
echo.
echo  ==== LISTO ====
echo  La app quedo en: %~dp0EMA-Alumbrado.apk
echo  Pasala al celular (WhatsApp, cable o Drive), tocala e instalala.
echo.
explorer /select,"%~dp0EMA-Alumbrado.apk"
pause
