# App de Android 1.4 — qué cambia y cómo armarla

## Qué trae
- **🎤 Micrófono para el Asistente.** Le hablás y escribe lo que dijiste (en castellano de Argentina). En la 1.3 el micrófono no andaba.
- **🔊 El Asistente habla.** Puede leer la respuesta en voz alta. Queda listo para el «modo charla» (hablás, contesta en voz alta y vuelve a escuchar solo).
- **📱 Datos de cada celular.** Modelo, versión de Android, batería y si está con WiFi o datos. Sirve para ver desde la oficina por qué un celu anda mal.
- **⏰ Recordatorios en el celular.** Avisos que el celu muestra a la hora que se programa, aunque no haya señal en ese momento.
  - El número sobre el ícono (cuántas cosas pendientes) sale en Samsung, Xiaomi y otros. **En los Motorola no sale el número**: Android muestra solo un puntito.
- **🔒 Entrar con huella o cara.** Si la persona lo activa, al abrir la app (o al volver después de un rato) pide la huella, la cara o el PIN del celular. No guarda contraseñas.

**Importante:** la app ya tiene todo esto adentro, pero **los botones aparecen recién con un index.html nuevo** (se programa después). Hasta entonces, la 1.4 anda igual que la 1.3.

## Cómo armarla (en la compu)
1. Descomprimí `AlumbradoApp_1.4.zip` **encima** de la carpeta `AlumbradoApp` de antes (reemplazar todo).
   - La carpeta `jdk21` que ya bajaste se sigue usando.
   - El archivo `android\app\google-services.json` ya viene adentro (es el mismo de la 1.3). Si te pregunta, reemplazalo.
2. Doble clic en **COMPILAR.bat**.
   - Esta vez baja algunas librerías nuevas: puede tardar unos minutos más que la última vez. No cierres la ventana.
3. Al final aparece **EMA-Alumbrado.apk** al lado de COMPILAR.bat.
4. Si sale un error: sacale una foto a la ventana y mandámela.

## Cómo instalarla en cada celular (sin perder nada)
1. Pasá el **EMA-Alumbrado.apk** al celular (WhatsApp, Drive o cable) y tocalo.
2. Tocá **Actualizar** (o Instalar). **No la desinstales antes**: así no se pierde el usuario, las fotos que esperan subir ni nada guardado.
3. Abrí la app: entra sola, con el mismo usuario.
4. Para ver que quedó bien: Ajustes del celular › Apps › EMA Alumbrado → abajo dice versión **1.4**.

## Qué va a preguntar el celular
Las preguntas aparecen **la primera vez que se usa cada cosa**, no al instalar:
- **Micrófono** («¿Permitir que EMA Alumbrado grabe audio?»): la primera vez que se toca el 🎤 del Asistente. → **Mientras se usa la app**.
- **Notificaciones**: si ya lo habían permitido con la 1.3, no vuelve a preguntar. Si pregunta → **Permitir**.
- **Huella o cara**: no aparece ningún cartel de permiso. Cuando la persona active «Pedir huella al abrir», el celu pide la huella para probar.
- Lo de antes sigue igual: ubicación («Permitir siempre» o «mientras se usa») y batería «Sin restricciones».

Si alguien tocó «No permitir» en el micrófono dos veces, Android ya no vuelve a preguntar: Ajustes › Apps › EMA Alumbrado › Permisos › Micrófono › Permitir.

## Para que el micrófono y la voz anden
- Usan los servicios de voz de Google del celular. Casi todos los Android los traen.
- Si el Asistente no habla en castellano: Ajustes › Sistema › Idioma › Salida de texto a voz › instalar «Español».
- El dictado necesita señal (salvo que el celu tenga bajado el español «sin conexión» en Ajustes de Google › Voz).
